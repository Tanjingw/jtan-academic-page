function dxdt=differential(t,x)
dxdt=[x(1)*(1-x(1))*(9-8*x(2));x(2)*(1-x(2))*(11-6*x(1))];
end