clear
%y-x
for i=0.1:0.2:0.9
    for j=0.1:0.2:0.9
        [T,Y]=ode45('differential',[0 20],[i j]);
        figure(1)
        grid on
        plot(T,Y(:,1),'r*-','linewidth',1);
        hold on
        plot(T,Y(:,2),'b--','linewidth',1);
        hold on
    end
end
axis([0 20 -0.1 1.1]);
set(gca,'XTick',[0:2:20],'YTick',[-0.1:0.1:1.1]);
xlabel('evolutionary steps');
ylabel('population');
legend('B','S')